<?php
// update_salary.php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $emp_no = $_POST['emp_no'];
    $new_salary = $_POST['salary'];

    $update_sql = "UPDATE salaries SET to_date = NOW() WHERE emp_no = ? AND to_date IS NULL";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("i", $emp_no);
    $stmt->execute();

    $insert_sql = "INSERT INTO salaries (emp_no, salary, from_date, to_date) VALUES (?, ?, NOW(), NULL)";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("id", $emp_no, $new_salary);
    $stmt->execute();

    echo "Salary updated successfully.";
}
?>
<form method="post">
    Employee ID: <input type="text" name="emp_no"><br>
    New Salary: <input type="text" name="salary"><br>
    <button type="submit">Update Salary</button>
</form>