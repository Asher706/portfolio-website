<?php
// fire_employee.php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $emp_no = $_POST['emp_no'];

    if (is_numeric($emp_no)) {
        // Delete the employee record
        $delete_query = "DELETE FROM employees WHERE emp_no = ?";
        $stmt = $conn->prepare($delete_query);
        $stmt->bind_param("i", $emp_no);
        if ($stmt->execute()) {
            echo "Employee fired successfully!";
        } else {
            echo "Error deleting employee: " . $stmt->error;
        }
    } else {
        echo "Invalid input! Employee ID must be numeric.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Fire Employee</title>
</head>
<body>
    <h1>Fire Employee</h1>
    <form method="POST">
        <label>Employee ID:</label>
        <input type="number" name="emp_no" required><br>
        <button type="submit">Fire Employee</button>
    </form>
</body>
</html>