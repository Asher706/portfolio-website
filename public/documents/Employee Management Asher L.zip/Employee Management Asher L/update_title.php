<?php
// update_title.php
include 'db_connect.php';

// Fetch all unique titles
$titles = $conn->query("SELECT DISTINCT title FROM titles");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $emp_no = $_POST['emp_no'];
    $new_title = $_POST['title'];

    if (is_numeric($emp_no)) {
        // End the current title record
        $update_query = "UPDATE titles SET to_date = CURDATE() WHERE emp_no = ? AND to_date IS NULL";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("i", $emp_no);
        $stmt->execute();

        // Insert a new title record
        $insert_query = "INSERT INTO titles (emp_no, title, from_date, to_date) VALUES (?, ?, CURDATE(), NULL)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("is", $emp_no, $new_title);
        if ($stmt->execute()) {
            echo "Title updated successfully!";
        } else {
            echo "Error updating title: " . $stmt->error;
        }
    } else {
        echo "Invalid input! Employee ID must be numeric.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Employee Title</title>
</head>
<body>
    <h1>Update Employee Title</h1>
    <form method="POST">
        <label>Employee ID:</label>
        <input type="number" name="emp_no" required><br>
        <label>New Title:</label>
        <select name="title" required>
            <?php while ($row = $titles->fetch_assoc()): ?>
                <option value="<?php echo $row['title']; ?>"><?php echo $row['title']; ?></option>
            <?php endwhile; ?>
        </select><br>
        <button type="submit">Update Title</button>
    </form>
</body>
</html>