<?php
// employee_dashboard.php
include 'db_connect.php';

$sql = "SELECT e.emp_no, e.first_name, e.last_name, e.birth_date, e.hire_date, 
        d.dept_name, t.title, s.salary 
        FROM employees e
        JOIN dept_emp de ON e.emp_no = de.emp_no
        JOIN departments d ON de.dept_no = d.dept_no
        JOIN titles t ON e.emp_no = t.emp_no
        JOIN salaries s ON e.emp_no = s.emp_no
        WHERE s.to_date IS NULL AND t.to_date IS NULL AND de.to_date IS NULL";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Employee Dashboard</title>
</head>
<body>
    <h1>Employee Dashboard</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Birth Date</th>
            <th>Hire Date</th>
            <th>Department</th>
            <th>Title</th>
            <th>Salary</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["emp_no"] . "</td><td>" . $row["first_name"] . " " . $row["last_name"] .
                     "</td><td>" . $row["birth_date"] . "</td><td>" . $row["hire_date"] .
                     "</td><td>" . $row["dept_name"] . "</td><td>" . $row["title"] .
                     "</td><td>" . $row["salary"] . "</td></tr>";
            }
        }
        ?>
    </table>
</body>
</html>