<!DOCTYPE html>
<html lang="en">
<head>
    <title>Employee Management</title>
</head>
<body>
    <h1>Employee Management System</h1>
    <a href="employee_dashboard.php">View Employee Details</a><br>
    <a href="update_salary.php">Update Salary</a><br>
    <a href="update_department.php">Change Department</a><br>
    <a href="update_title.php">Change Title</a><br>
    <a href="fire_employee.php">Fire Employee</a><br>
</body>
</html>